// Braden Begnaud
// Your ULID
// CMPS 261
// Program Description: description of actions of code
// Certificate of Authenticity: I certify that the code in the method functions including method
// function main of this project are entirely my own work.

import java.beans.Expression;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.Scanner;
import java.util.Stack;

public class Main {

    // this method generates a 5 million integer linked list then compares the two iterator methods, one using an actual iterator and another using a for loop for time. Has no inputs and returns nothing
    // but prints the times for the iterations

    public static void linkedListMethod() {
        LinkedList<Integer> integerList = new LinkedList<Integer>();
        for (int i = 0; i < 5000000; i++) {
            integerList.add((int) (Math.random() * 100));
        }
        Iterator<Integer> iterator = integerList.iterator();
        long startTime = System.currentTimeMillis();
        while(iterator.hasNext()) {
            iterator.next();
        }
        long endTime = System.currentTimeMillis();
        long executionTime = (endTime-startTime);
        System.out.println(executionTime);
        long startTime2 = System.currentTimeMillis();
        for (int i = 1; i < 5000000; i++) {
            integerList.get(i);
            System.out.println(i);
        }
        long endTime2 = System.currentTimeMillis();
        long executionTime2 = (endTime2-startTime2);
        System.out.println(executionTime2);
    }

    // this method takes an equation in postfix form and calculates it using stacks. Once it runs out of operators, it returns the only value left in the stack, the answer.

    public static double postfixEvaluation(String equation) {
        Stack<Double> operands = new Stack<>();
        Scanner scanner = new Scanner(equation);
        String inputValue;
        double operand1;
        double operand2;
        double expression = 0;
        operands.push(expression);
        while (scanner.hasNext()) {
            inputValue = scanner.next();
            if (inputValue.equals("+")) {
                operand1 = operands.pop();
                operand2 = operands.pop();
                expression = operand2 + operand1;
                operands.push(expression);
            }
            else if (inputValue.equals("-")) {
                operand1 = operands.pop();
                operand2 = operands.pop();
                expression = operand2 - operand1;
                operands.push(expression);
            }
            else if (inputValue.equals("*")) {
                operand1 = operands.pop();
                operand2 = operands.pop();
                expression = operand2 * operand1;
                operands.push(expression);
            }
            else if (inputValue.equals("/")) {
                operand1 = operands.pop();
                operand2 = operands.pop();
                expression = operand2 / operand1;
                operands.push(expression);
            }
            else if (inputValue.equals(" ")) {
            }
            else {
                operands.push(Double.parseDouble(String.valueOf(inputValue)));
            }
        }
        return operands.pop();
    }

// executes the two previous functions, implementing a loop to allow for several equations to be entered.

    public static void main(String[] args) {
        linkedListMethod();
        Scanner scanner = new Scanner(System.in);
        System.out.println("Would you like to enter a number? (y/n)");
        char answer = scanner.next().charAt(0);
        scanner.nextLine();
        while (answer != 'n') {
            System.out.println("Enter equation in postfix :");
            String equation = scanner.nextLine();
            System.out.println(postfixEvaluation(equation));
            System.out.println("Enter another? (y/n)");
            answer = scanner.next().charAt(0);
            scanner.nextLine();
        }
    }
    }
