// Braden Begnaud
// C00462494
// CMPS 261
// Program Description: taking a max heap program and changing it into a min heap program
// Certificate of Authenticity:
// I certify that the code in the method functions
// including method function main of this project are
// entirely my own work.

        package heapsortexample;

/**@author Y. Daniel Liang*/
public class HeapSort {

    /**Heap sort method*/
    public static <E extends Comparable> void heapSort(E[] list) {
        // Create a Heap of integers
        Heap<E> heap = new Heap<E>();

        // Add elements to the heap
        for (int i = 0; i < list.length; i++) {
            heap.add(list[i]);
        }

        // Remove elements from the heap and return to list
        for (int i = list.length - 1; i >= 0; i--) {
            list[i] = heap.remove();
        }
    }

    /**test the heap sort*/
    public static void main(String[] args) {
        Integer[] list = {2, 3, 2, 5, 6, 1, -2, 3, 14, 12};
        heapSort(list);
        for (int i = 0; i < list.length; i++) {
            System.out.print(list[i] + " ");
        }
        System.out.println();
    }
}
