package heapsortexample;

/**
 * @author Y. Daniel Liang
 */
public class Heap<E extends Comparable> {

    private java.util.ArrayList<E> list = new java.util.ArrayList<E>();

    /**
     * Create a default heap
     */
    public Heap() {
    }

    /**
     * Create a heap from an array of objects
     */
    public Heap(E[] objects) {
        for (int i = 0; i < objects.length; i++) {
            add(objects[i]);
        }
    }

    /**
     * Get the number of nodes in the tree
     */
    public int getSize() {
        return list.size();
    }

    /**
     * Add a new object into the heap, putting it into the correct spot, swapping objects so the heap is a minHeap
     *
     * @param newObject the given object to be inserted into the minHeap
     */
    public void add(E newObject) {
        list.add(newObject); // Append to the heap
        int currentIndex = list.size() - 1; // The index of the last node

        while (currentIndex > 0) {
            int parentIndex = (currentIndex - 1);
            int nextNode = currentIndex + 1;

            // Swap if the current object is less than its parent
            if (parentIndex >= 0 && list.get(currentIndex).compareTo(
                    list.get(parentIndex)) < 0) {
                E temp = list.get(currentIndex);
                list.set(currentIndex, list.get(parentIndex));
                list.set(parentIndex, temp);
            }
            // check next nodes to swap if greater than
            else if (nextNode < list.size() && list.get(nextNode).compareTo(currentIndex) < 0) {
                E temp = list.get(currentIndex);
                list.set(currentIndex, list.get(nextNode));
                list.set(nextNode, temp);
            } else {
                break; // the tree is a heap now
            }
            currentIndex = parentIndex;
        }
    }

    /**
     * Remove the root from the heap, returning the removed value, which is always the minimum value (root node)
     *
     * @return E returns the root node of the heap, which is the minimum value
     */
    public E remove() {
        if (list.size() == 0) {
            return null;
        }
        E removedObject = list.get(0);
        list.remove(0);
        return removedObject;
    }
}
